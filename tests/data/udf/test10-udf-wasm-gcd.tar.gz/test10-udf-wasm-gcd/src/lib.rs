use arrow_udf::function;
use arrow_udf::types::Decimal;
use arrow_udf::types::NaiveDate;
use arrow_udf::types::NaiveDateTime;

#[function("wasm_constant()->int32")]
fn wasm_constant() -> i32 {
    42
}

#[function("wasm_gcd(int, int)->int")]
fn wasm_gcd(mut a: i32, mut b: i32) -> i32 {
    while b != 0 {
        (a, b) = (b, a % b);
    }
    a
}

// Least Common Multiple
#[function("wasm_lcm(int, int)->int")]
fn wasm_lcm(a: i32, b: i32) -> i32 {
    let gcd = wasm_gcd(a, b);
    (a * b) / gcd
}

// Factorial
#[function("wasm_factorial(int)->int")]
fn wasm_factorial(n: i32) -> i32 {
    if n <= 1 {
        1
    } else {
        n * wasm_factorial(n - 1)
    }
}

// Fibonacci
#[function("wasm_fibonacci(int)->int")]
fn wasm_fibonacci(n: i32) -> i32 {
    if n <= 1 {
        n
    } else {
        wasm_fibonacci(n - 1) + wasm_fibonacci(n - 2)
    }
}

// Prime Check
#[function("wasm_is_prime(int)->bool")]
fn wasm_is_prime(n: i32) -> bool {
    if n <= 1 {
        return false;
    }
    if n <= 3 {
        return true;
    }
    if n % 2 == 0 || n % 3 == 0 {
        return false;
    }
    let mut i = 5;
    while i * i <= n {
        if n % i == 0 || n % (i + 2) == 0 {
            return false;
        }
        i += 6;
    }
    true
}

#[function("wasm_identity_boolean(boolean)->boolean")]
fn wasm_identity_boolean(value: bool) -> bool {
    value
}

#[function("wasm_identity_int8(int8)->int8")]
fn wasm_identity_int8(value: i8) -> i8 {
    value
}

#[function("wasm_identity_int16(int16)->int16")]
fn wasm_identity_int16(value: i16) -> i16 {
    value
}

#[function("wasm_identity_int32(int32)->int32")]
fn wasm_identity_int32(value: i32) -> i32 {
    value
}

#[function("wasm_identity_int64(int64)->int64")]
fn wasm_identity_int64(value: i64) -> i64 {
    value
}

#[function("wasm_identity_uint8(uint8)->uint8")]
fn wasm_identity_uint8(value: u8) -> u8 {
    value
}

#[function("wasm_identity_uint16(uint16)->uint16")]
fn wasm_identity_uint16(value: u16) -> u16 {
    value
}

#[function("wasm_identity_uint32(uint32)->uint32")]
fn wasm_identity_uint32(value: u32) -> u32 {
    value
}

#[function("wasm_identity_uint64(uint64)->uint64")]
fn wasm_identity_uint64(value: u64) -> u64 {
    value
}

#[function("wasm_identity_float32(float32)->float32")]
fn wasm_identity_float32(value: f32) -> f32 {
    value
}

#[function("wasm_identity_float64(float64)->float64")]
fn wasm_identity_float64(value: f64) -> f64 {
    value
}

#[function("wasm_identity_decimal(decimal)->decimal")]
fn wasm_identity_decimal(value: Decimal) -> Decimal {
    value
}

#[function("wasm_identity_date(date)->date")]
fn wasm_identity_date(value: NaiveDate) -> NaiveDate {
    value
}

#[function("wasm_identity_timestamp(timestamp)->timestamp")]
fn wasm_identity_timestamp(value: NaiveDateTime) -> NaiveDateTime {
    value
}

#[function("wasm_identity_string(string)->string")]
fn wasm_identity_string(value: &str) -> &str {
    value
}

#[function("wasm_string_length(string)->int32")]
fn wasm_string_length(value: &str) -> i32 {
    value.len() as i32
}

#[function("wasm_identity_binary(largebinary)->largebinary")]
fn wasm_identity_binary(value: &[u8]) -> &[u8] {
    value
}

#[function("wasm_array_sum_int32(int32[])->int32")]
fn wasm_array_sum_int32(values: &[i32]) -> i32 {
    values.iter().sum()
}

#[function("wasm_array_sum_float64(float64[])->float64")]
fn wasm_array_sum_float64(values: &[f64]) -> f64 {
    values.iter().sum()
}
