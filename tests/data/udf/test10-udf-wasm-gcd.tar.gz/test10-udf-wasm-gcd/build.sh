#!/usr/bin/env bash

set -euo pipefail

cargo build --release --target wasm32-wasip1
cp target/wasm32-wasip1/release/test10_udf_wasm_gcd.wasm .
zstd --force test10_udf_wasm_gcd.wasm
