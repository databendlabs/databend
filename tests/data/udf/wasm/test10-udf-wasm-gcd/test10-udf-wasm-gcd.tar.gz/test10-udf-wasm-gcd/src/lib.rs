use arrow_udf::function;

#[function("wasm_gcd(int, int)->int")]
fn wasm_gcd(mut a: i32, mut b: i32) -> i32 {
    while b != 0 {
        (a, b) = (b, a % b);
    }
    a
}

// Least Common Multiple
#[function("wasm_lcm(int, int)->int")]
fn wasm_lcm(a: i32, b: i32) -> i32 {
    let gcd = wasm_gcd(a, b);
    (a * b) / gcd
}

// Factorial
#[function("wasm_factorial(int)->int")]
fn wasm_factorial(n: i32) -> i32 {
    if n <= 1 {
        1
    } else {
        n * wasm_factorial(n - 1)
    }
}

// Fibonacci
#[function("wasm_fibonacci(int)->int")]
fn wasm_fibonacci(n: i32) -> i32 {
    if n <= 1 {
        n
    } else {
        wasm_fibonacci(n - 1) + wasm_fibonacci(n - 2)
    }
}

// Prime Check
#[function("wasm_is_prime(int)->bool")]
fn wasm_is_prime(n: i32) -> bool {
    if n <= 1 {
        return false;
    }
    if n <= 3 {
        return true;
    }
    if n % 2 == 0 || n % 3 == 0 {
        return false;
    }
    let mut i = 5;
    while i * i <= n {
        if n % i == 0 || n % (i + 2) == 0 {
            return false;
        }
        i += 6;
    }
    true
}
