cargo build --release --target wasm32-wasi
